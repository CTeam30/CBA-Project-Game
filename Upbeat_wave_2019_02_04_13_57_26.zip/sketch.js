function setup() {
  createCanvas(800, 450);
	background(120);
}

function draw() {
	fill(255, 255, 255, 20, 70)
	rect(mouseX, mouseY, 20, 20)
}